<?php
require 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Akses tidak sah.");
}

$nomor_nota = $_POST['nomor_nota'];
$kasir_id = (int)$_POST['kasir_id'];
$pelanggan_id = $_POST['pelanggan_id']; 
$keterangan = $_POST['keterangan'];
$total_transaksi = (int)$_POST['total_transaksi'];
$detail_barang = $_POST['detail'];

if (empty($detail_barang)) {
    die("Detail transaksi kosong. Tidak ada barang yang dipilih.");
}

$conn->begin_transaction();
$sukses = true;

try {
    $waktu_sekarang = date('Y-m-d H:i:s');

    $sql_transaksi = "INSERT INTO penjualan.transaksi (waktu_transaksi, keterangan, total, pelanggan_id)
                      VALUES (?, ?, ?, ?)";
    $stmt_transaksi = $conn->prepare($sql_transaksi);
    $stmt_transaksi->bind_param("ssis", $waktu_sekarang, $keterangan, $total_transaksi, $pelanggan_id);

    if (!$stmt_transaksi->execute()) {
        throw new Exception("Gagal menyimpan data Transaksi: " . $stmt_transaksi->error);
    }

    $transaksi_id = $conn->insert_id;
    $stmt_transaksi->close();

    $sql_nota = "INSERT INTO penjualan.nota (transaksi_id, nomor_nota, tanggal_cetak, kasir_id)
                 VALUES (?, ?, ?, ?)";
    $stmt_nota = $conn->prepare($sql_nota);
    $stmt_nota->bind_param("issi", $transaksi_id, $nomor_nota, $waktu_sekarang, $kasir_id);

    if (!$stmt_nota->execute()) {
        throw new Exception("Gagal menyimpan data Nota: " . $stmt_nota->error);
    }
    $stmt_nota->close();

    $sql_detail = "INSERT INTO penjualan.transaksi_detail (transaksi_id, barang_id, harga, qty)
                   VALUES (?, ?, ?, ?)";
    $stmt_detail = $conn->prepare($sql_detail);
    
    $sql_update_stok = "UPDATE penjualan.barang SET stok = stok - ? WHERE id = ?";
    $stmt_update_stok = $conn->prepare($sql_update_stok);
    
    foreach ($detail_barang as $item) {
        $barang_id = (int)$item['barang_id'];
        $harga = (int)$item['harga'];
        $qty = (int)$item['qty'];

        if ($barang_id <= 0 || $qty <= 0) continue; 

        $stmt_detail->bind_param("iiii", $transaksi_id, $barang_id, $harga, $qty);
        if (!$stmt_detail->execute()) {
            throw new Exception("Gagal menyimpan Detail Barang: " . $stmt_detail->error);
        }
        
        $stmt_update_stok->bind_param("ii", $qty, $barang_id);
        if (!$stmt_update_stok->execute()) {
            throw new Exception("Gagal mengurangi stok barang ID {$barang_id}: " . $stmt_update_stok->error);
        }
        
        if ($stmt_update_stok->affected_rows === 0) {
           
        }
    }
    $stmt_detail->close();
    $stmt_update_stok->close();

    $conn->commit();
    echo "<h2>✅ Transaksi Berhasil Disimpan!</h2>";
    echo "Data Transaksi, Nota, dan Detail Barang telah tersimpan bersamaan.";
    echo " **Stok barang berhasil diperbarui.**";
    echo "<br>Nomor Transaksi: <b>{$transaksi_id}</b>";
    echo "<br>Nomor Nota: <b>{$nomor_nota}</b>";

} catch (Exception $e) {
    $conn->rollback();
    echo "<h2>❌ Gagal Menyimpan Transaksi!</h2>";
    echo "Terjadi kesalahan: " . $e->getMessage();
    $sukses = false;
}

$conn->close();
?>