<?php
require 'koneksi.php';

$sql_barang = "SELECT id, kode_barang, nama_barang, harga FROM penjualan.barang ORDER BY nama_barang";
$result_barang = $conn->query($sql_barang);
$barang_list = [];
while ($row = $result_barang->fetch_assoc()) {
    $barang_list[] = $row;
}

$sql_pelanggan = "SELECT id, nama FROM penjualan.pelanggan ORDER BY nama";
$result_pelanggan = $conn->query($sql_pelanggan);
$pelanggan_list = [];
while ($row = $result_pelanggan->fetch_assoc()) {
    $pelanggan_list[] = $row;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Input Transaksi Penjualan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f7f6;
            color: #333;
        }
        h2, h3 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 10px;
        }
        #detail-barang-table {
            width: 100%;
        }
        #detail-barang-table thead th {
            background-color: #3498db;
            color: white;
            text-align: left;
        }
        #detail-barang-table tfoot td {
            background-color: #ecf0f1;
            font-weight: bold;
        }
        input[type="text"], input[type="number"], textarea, select {
            width: calc(100% - 10px);
            padding: 8px;
            margin: 4px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        #detail-barang-table input[type="number"], #detail-barang-table select {
             width: 90%;
        }
        button {
            background-color: #2ecc71;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
            transition: background-color 0.3s;
        }
        button[type="submit"] {
            background-color: #2980b9;
            width: 100%;
        }
        button:hover {
            opacity: 0.9;
        }
        button[onclick^="hapus"] {
            background-color: #e74c3c;
            padding: 5px 10px;
            font-size: 14px;
            width: auto;
        }
    </style>
</head>
<body>

<h2>Form Transaksi Penjualan Baru</h2>

<form action="simpan_transaksi.php" method="POST">
    <h3>Data Transaksi (Master)</h3>
    <table>
        <tr>
            <td>Nomor Nota Otomatis</td>
            <td><input type="text" name="nomor_nota" value="TRX-<?php echo time(); ?>" readonly></td>
        </tr>
        <tr>
            <td>ID Kasir</td>
            <td><input type="number" name="kasir_id" value="1" required placeholder="Contoh: 1"> 
            </td>
        </tr>
        <tr>
            <td>ID Pelanggan</td>
            <td>
                <select name="pelanggan_id" required>
                    <option value="UMUM">-- Pelanggan Umum --</option>
                    <?php 
                    foreach ($pelanggan_list as $pelanggan) {
                        echo "<option value='{$pelanggan['id']}'>{$pelanggan['nama']} ({$pelanggan['id']})</option>";
                    }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Keterangan</td>
            <td><textarea name="keterangan" rows="3"></textarea></td>
        </tr>
    </table>

    <h3>Detail Barang (Detail)</h3>
    <table id="detail-barang-table">
        <thead>
            <tr>
                <th>Barang</th>
                <th>Harga Satuan</th>
                <th>Jumlah (Qty)</th>
                <th>Sub Total</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            </tbody>
        <tfoot>
            <tr>
                <td colspan="3" align="right">Total Keseluruhan:</td>
                <td id="grand-total">0</td>
                <td><button type="button" onclick="tambahBaris()">Tambah Barang</button></td>
            </tr>
        </tfoot>
    </table>
    
    <input type="hidden" name="total_transaksi" id="input-grand-total">

    <br>
    <button type="submit">Simpan Transaksi & Cetak Nota</button>
</form>

<script>
let rowCount = 0;
const barangList = <?php echo json_encode($barang_list); ?>;

function tambahBaris() {
    rowCount++;
    const tableBody = document.querySelector('#detail-barang-table tbody');
    const newRow = tableBody.insertRow();
    
    newRow.innerHTML = `
        <td>
            <select name="detail[${rowCount}][barang_id]" onchange="setHarga(this, ${rowCount})" required>
                <option value="">Pilih Barang</option>
                ${barangList.map(b => `<option value="${b.id}" data-harga="${b.harga}">${b.nama_barang} (${b.kode_barang})</option>`).join('')}
            </select>
        </td>
        <td>
            <input type="number" name="detail[${rowCount}][harga]" id="harga-${rowCount}" value="0" readonly>
        </td>
        <td>
            <input type="number" name="detail[${rowCount}][qty]" id="qty-${rowCount}" value="1" min="1" onchange="hitungSubTotal(${rowCount})" required>
        </td>
        <td id="subtotal-${rowCount}">0</td>
        <td>
            <button type="button" onclick="hapusBaris(this, ${rowCount})">Hapus</button>
        </td>
    `;
    hitungGrandTotal();
}

function setHarga(selectElement, rowIndex) {
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    const harga = selectedOption.getAttribute('data-harga') || 0;
    document.getElementById(`harga-${rowIndex}`).value = harga;
    hitungSubTotal(rowIndex);
}

function hitungSubTotal(rowIndex) {
    const harga = parseInt(document.getElementById(`harga-${rowIndex}`).value) || 0;
    const qty = parseInt(document.getElementById(`qty-${rowIndex}`).value) || 0;
    const subtotal = harga * qty;
    
    document.getElementById(`subtotal-${rowIndex}`).innerText = subtotal.toLocaleString('id-ID');
    hitungGrandTotal();
}

function hitungGrandTotal() {
    let grandTotal = 0;
    const rows = document.querySelectorAll('#detail-barang-table tbody tr');
    rows.forEach((row, index) => {
        const subtotalElement = document.getElementById(`subtotal-${index + 1}`);
        if (subtotalElement) {
            const subtotalText = subtotalElement.innerText.replace(/\./g, '');
            grandTotal += parseInt(subtotalText) || 0;
        }
    });

    document.getElementById('grand-total').innerText = grandTotal.toLocaleString('id-ID');
    document.getElementById('input-grand-total').value = grandTotal;
}

function hapusBaris(button, rowIndex) {
    const row = button.parentNode.parentNode;
    row.remove();
    hitungGrandTotal();
}

document.addEventListener('DOMContentLoaded', tambahBaris);
</script>

</body>
</html>